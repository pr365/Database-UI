#!flask/bin/python
from flask import Flask, redirect, url_for
from flask import Response
import json, decimal
import psycopg2
from flask_cors import CORS
from sshtunnel import SSHTunnelForwarder
from flask import (Flask, Response, request, 
                   render_template, redirect, 
                   url_for, make_response,
                   jsonify)
import pandas as pd 

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return super(DecimalEncoder, self).default(o)

def decimal_default(obj):
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    raise TypeError        
        
app = Flask(__name__)
CORS(app)
PORT=5432
tunnel = SSHTunnelForwarder(('moat.cis.uab.edu', 22),ssh_username='pranith', ssh_password='*******',remote_bind_address=('cisdb', PORT),local_bind_address=('localhost', 6535))
tunnel.start()
db = psycopg2.connect(
    dbname='pranith',
    user='pranithweb',
    password='pranith',
    host=tunnel.local_bind_host,
    port=tunnel.local_bind_port,
)
cur = db.cursor()

@app.route('/')
def home():
  return redirect(url_for('static', filename='home.html'))
  
@app.route("/employee", methods=["GET","POST"])
def employee():
  if request.method == 'POST' or request.method == 'GET':
    email = request.form['email']
    print(email)
    strng = "select * from customer where custid ="+str(email)
    if email == 'all':
      strng = "select * from customer"
    cur.execute(strng)
    tup = cur.fetchall()  
    column_names=['custid','firstname','lastname','ssn','age','phonenumber','dl_num']
    df = pd.DataFrame(tup, columns=column_names)
    data=df.to_csv(index = None, header=True)
    print(data)
    return data

@app.route("/dependents", methods=['GET','POST'])
def dependents():
  email = request.form['email']
  print(email)
  strng = "select * from policy where policy_num ="+"'"+str(email)+"'"
  if email == 'all':
      strng = "select * from policy"
  cur.execute(strng)
  column_names=['policy_num','policy_type','category','price','coverage_amt','issued_date','exp_date','custid']
  tup = cur.fetchall()
  df = pd.DataFrame(tup, columns=column_names)
  data=df.to_csv(index = None, header=True)
  print(data)
  return data

@app.route("/plans", methods=['GET','POST'])
def plans():
  email = request.form['email']
  print(email)
  strng = "select * from plan"
  cur.execute(strng)
  column_names=['plan_type','plan_category','price_per_month','coverage_amt']
  tup = cur.fetchall()
  df = pd.DataFrame(tup, columns=column_names)
  data=df.to_csv(index = None, header=True)
  print(data)
  return data
    
if __name__ == '__main__':
    app.run(host='localhost', port=5007)    
