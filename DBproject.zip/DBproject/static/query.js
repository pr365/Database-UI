var width = 600; 
var height = 550; 

var svg_table1 = d3.select("#my_svg").append("svg")
    .attr("width", 570)
    .attr("height", height)
    .style("background", "#dcdcdc")
    .style("margin", "auto")
    .style("border", "3px solid black").style("border-radius", "15px")

    var svg_table3 = d3.select("#my_svg").append("svg")
    .attr("width", 430)
    .attr("height", height)
    .style("background", "#dcdcdc")
    .style("margin", "auto")
    .style("border", "3px solid black").style("border-radius", "15px")
    
    var svg_table2 = d3.select("#my_svg").append("svg")
    .attr("width", width+70)
    .attr("height", height)
    .style("background", "#dcdcdc")
    .style("margin", "auto")
    .style("border", "3px solid black").style("border-radius", "15px")

function tabulate(data, columns,i) {
  console.log(data)
  if(i==0){
      d3.select(".foreignObject1").remove();
    var tab = svg_table1.append("foreignObject")
      .attr("width", 570)
      .attr("height", 550)
      .attr("x",-30)
      .attr("y",0)
      .attr("class","foreignObject1")

    var er=tab.append("xhtml:body")

      var table= er.append("table");
      thead = table.append("thead");
      tbody = table.append("tbody");

// append the header row
thead.append("tr")
.selectAll("th")
.data(columns)
.enter()
.append("th")
    .text(function(column) { return column; }).style("font-size", "13px");

// create a row for each object in the data
var rows = tbody.selectAll("tr").data(data)
.enter()
.append("tr");

// create a cell in each row for each column
var cells = rows.selectAll("td").data(function(row) {
    return columns.map(function(column) {
        return {column: column, value: row[column]};
    });
})
.enter()
.append("td")
.attr("style", "font-family: Courier") // sets the font style
    .html(function(d) { return d.value; }).style("font-size", "13px");

}
    if(i==1) {
    d3.select(".foreignObject2").remove();
    var tab = svg_table2.append("foreignObject")
    .attr("width", 600+70)
    .attr("height", 550)
    .attr("x",-30)
    .attr("y",0)
    .attr("class","foreignObject2")
    var er = tab.append("xhtml:body")
    var table= er.append("table");
    thead = table.append("thead");
    tbody = table.append("tbody");

// append the header row
thead.append("tr")
.selectAll("th")
.data(columns)
.enter()
.append("th")
    .text(function(column) { return column; }).style("font-size", "13px");

// create a row for each object in the data
var rows = tbody.selectAll("tr").data(data)
.enter()
.append("tr");

// create a cell in each row for each column
var cells = rows.selectAll("td").data(function(row) {
    return columns.map(function(column) {
        return {column: column, value: row[column]};
    });
})
.enter()
.append("td")
.attr("style", "font-family: Courier") // sets the font style
    .html(function(d) { return d.value; }).style("font-size", "13px");

}
if(i==2){
    d3.select(".foreignObject3").remove();
  var tab = svg_table3.append("foreignObject")
    .attr("width", 430)
    .attr("height", 550)
    .attr("x",-30)
    .attr("y",0) 
    .attr("class","foreignObject3")

  var er=tab.append("xhtml:body")

    var table= er.append("table");
    thead = table.append("thead");
    tbody = table.append("tbody");

// append the header row
thead.append("tr")
.selectAll("th")
.data(columns)
.enter()
.append("th")
  .text(function(column) { return column; }).style("font-size", "13px");

// create a row for each object in the data
var rows = tbody.selectAll("tr").data(data)
.enter()
.append("tr");

// create a cell in each row for each column
var cells = rows.selectAll("td").data(function(row) {
  return columns.map(function(column) {
      return {column: column, value: row[column]};
  });
})
.enter()
.append("td")
.attr("style", "font-family: Courier") // sets the font style
  .html(function(d) { return d.value; }).style("font-size", "13px");

}
    
}

function table_customer(){
      //var url = 'http://localhost:5007/employee'
      var t = document.getElementById('configname').value
      $.ajax({
        data : {
            email : t
        },
        type : 'POST',
        url : 'http://localhost:5007/employee'
    }).done(function(data) {
        typeof(data)
        var data = d3.csvParse(data);
        var i = 0;
        tabulate(data, ['custid','firstname','lastname','ssn','age','phonenumber','dl_num'],i);
    });

    
      //d3.csv('http://localhost:5007/employee').then(function(data){
        //  console.log(data);
    //tabulate(data, [ "emp_id", "name", "age", "sex", "salary" ]);
      //  });       

}

function table_policynum(){
      //var url = 'http://localhost:5007/dependents'
      var t = document.getElementById('configname1').value
      $.ajax({
        data : {
            email : t
        },
        type : 'POST',
        url : 'http://localhost:5007/dependents'
    }).done(function(data) {
        console.log(data)
        var data = d3.csvParse(data);
        var i=1;
        tabulate(data, ['policy_num','policy_type','category','price','coverage_amt','issued_date','exp_date','custid'],i);
    });
    
      //d3.csv('http://localhost:5007/dependents').then(function(data){
     //   console.log(data);
    //tabulate(data, ['policy_num','policy_type','category','price','coverage_amt','issued_date','exp_date','custid']);
     //   });
}

function table_displayplans(){
    //var url = 'http://localhost:5007/dependents'
    var t = document.getElementById('configname3').value
    $.ajax({
      data : {
          email : t
      },
      type : 'POST',
      url : 'http://localhost:5007/plans'
  }).done(function(data) {
      console.log(data)
      var data = d3.csvParse(data);
      var i=2;
      tabulate(data, ['plan_type','plan_category','price_per_month','coverage_amt'],i);
  });
  
    //d3.csv('http://localhost:5007/dependents').then(function(data){
   //   console.log(data);
  //tabulate(data, [ "dep_id", "emp_id", "name", "age", "sex"]);
   //   });
}